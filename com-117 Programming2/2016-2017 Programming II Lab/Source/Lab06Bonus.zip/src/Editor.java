import objects.*;
import objects.Rectangle;
import objects.Shape;

import java.util.List;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Random;
import java.util.Stack;

import static java.awt.event.MouseEvent.BUTTON1;

public class Editor extends JFrame {

    class CanvasPanel extends JPanel {

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHints(
                new RenderingHints(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
                )
            );

            for (objects.Shape shape : shapes) {
                shape.draw(g2);
            }

            if (shapeInConstruction != null) {
                shapeInConstruction.draw(g2);
            }

            if (shapeToConstruct != null) {
                shapeToConstruct.draw(g2);
            }
        }

    }

    public static final String SHAPE_FILE_NAME = ".editor.shapes.dat";

    private static final String HELP_MESSAGE =
        "<html>" +
            "<b>Key 1</b>: to select <i>Rectangle</i>. <b>Key 2</b>: to select <i>Circle</i><br>" +
            "<b>Left mouse button</b> (press and move): draw the selected shape<br>" +
            "<b>Right mouse button</b> (press and move): select one or multiple shapes<br>" +
            "<b>Delete</b>: delete selected shapes. <b>C</b>: select a random fill color. " +
              "<b>CTRL+Z</b>: undo adding the previous shape<br>" +
            "<br>" +
            "<i>The program saves and restores the collection of shapes from the file <i>'" + SHAPE_FILE_NAME +
              "'</i> in the home directory.</i>" +
        "</html>";

    private static final int FRAME_WIDTH = 1024;
    private static final int FRAME_HEIGHT = 768;

    public static final int MINIMUM_DISTANCE_TO_CREATE_SHAPE = 20 * 20;

    public static final int PREVIEW_MARGIN = 10;
    public static final int PREVIEW_SIZE = 100;

    private static Random random = new Random();

    private Stack<objects.Shape> shapes;

    private objects.Shape shapeToConstruct;
    private objects.Shape shapeInConstruction;
    private objects.Shape previousSelectedShape;
    private int cursorPressedX, cursorPressedY;

    public Editor() {
        shapes = new Stack<>();

        shapeToConstruct = getInitialRectangle();
        shapeInConstruction = previousSelectedShape = null;
        cursorPressedX = cursorPressedY = 0;

        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setLocationRelativeTo(null);
        setExtendedState(getExtendedState() | MAXIMIZED_BOTH);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exit();
            }
        });

        CanvasPanel canvasPanel = new CanvasPanel();
        canvasPanel.setBackground(Color.darkGray);
        canvasPanel.setFocusable(true);
        canvasPanel.setLayout(null);
        canvasPanel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if ((e.getKeyCode() == KeyEvent.VK_Z) && ((e.getModifiers() & KeyEvent.CTRL_MASK) != 0)) {
                    undoShapeAddition();
                    return;
                }

                switch (e.getKeyCode()) {
                    case KeyEvent.VK_C:
                        selectRandomFillColor();
                        break;
                    case KeyEvent.VK_1:
                        selectRectangle();
                        break;
                    case KeyEvent.VK_2:
                        selectCircle();
                        break;
                    case KeyEvent.VK_DELETE:
                        removeSelectedShapes();
                        break;
                }
            }
        });
        canvasPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.getButton() == BUTTON1) {
                    addShapeInConstruction(e.getX(), e.getY());
                } else if (e.getButton() == MouseEvent.BUTTON3) {
                    boolean continiously = false;
                    selectShape(continiously, e.getX(), e.getY());
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                finalizeShapeInConstruction(e.getX(), e.getY());
            }
        });
        canvasPanel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    resizeShapeInConstruction(e.getX(), e.getY());
                } else if (SwingUtilities.isRightMouseButton(e)) {
                    boolean continiously = true;
                    selectShape(continiously, e.getX(), e.getY());
                }
            }
        });
        add(canvasPanel);

        JLabel informationLabel = new JLabel(HELP_MESSAGE);
        informationLabel.setForeground(Color.WHITE);
        canvasPanel.add(informationLabel);

        Insets insets = canvasPanel.getInsets();
        Dimension size = informationLabel.getPreferredSize();
        informationLabel.setBounds(
            PREVIEW_SIZE + PREVIEW_MARGIN * 2 + insets.left,
            PREVIEW_MARGIN + insets.top,
            size.width,
            size.height
        );

        shapes = loadShapes();
    }

    private void exit() {
        saveShapes(shapes);
        System.exit(0);
    }

    private void undoShapeAddition() {
        if (shapes.size() > 0) {
            shapes.pop();

            repaint();
        }
    }

    private void selectRandomFillColor() {
        shapeToConstruct.setColor(getRandomColor());

        repaint();
    }

    private void selectRectangle() {
        Color rectangleColor = shapeToConstruct.getColor();
        shapeToConstruct = getInitialRectangle();
        shapeToConstruct.setColor(rectangleColor);

        repaint();
    }

    private void selectCircle() {
        Color circleColor = shapeToConstruct.getColor();
        shapeToConstruct = getInitialCircle();
        shapeToConstruct.setColor(circleColor);

        repaint();
    }

    private void removeSelectedShapes() {
        shapes.removeIf(Shape::isSelected);

        repaint();
    }

    private void addShapeInConstruction(int x, int y) {
        shapeInConstruction = (Shape) shapeToConstruct.clone();
        if (shapeInConstruction != null) {
            shapeInConstruction.updateBounds(0, 0);
            shapeInConstruction.setX(x);
            shapeInConstruction.setY(y);

            cursorPressedX = x;
            cursorPressedY = y;

            repaint();
        }
    }

    private void resizeShapeInConstruction(int x, int y) {
        if (shapeInConstruction != null) {
            int width = x - cursorPressedX;
            int height = y - cursorPressedY;
            int shapeX = shapeInConstruction.getX();
            int shapeY = shapeInConstruction.getY();
            if (width < 0) {
                width = -width;
                shapeX = cursorPressedX - width;
            }
            if (height < 0) {
                height = -height;
                shapeY = cursorPressedY - height;
            }

            if (!shapeInConstruction.isPositionedAtCenter()) {
                shapeInConstruction.setX(shapeX);
                shapeInConstruction.setY(shapeY);
            }
            shapeInConstruction.updateBounds(width, height);

            repaint();
        }
    }

    private void finalizeShapeInConstruction(int x, int y) {
        if (shapeInConstruction != null) {
            int dx = x - cursorPressedX;
            int dy = y - cursorPressedY;
            if (dx * dx + dy * dy > MINIMUM_DISTANCE_TO_CREATE_SHAPE) {
                shapes.add(shapeInConstruction);
                shapeInConstruction = null;
            }

            repaint();
        }
    }

    private void selectShape(boolean continiously, int x, int y) {
        int index = findShape(shapes, x, y);
        if (index >= 0) {
            Shape shape = shapes.get(index);
            if (continiously) {
                if (shape != previousSelectedShape) {
                    shape.setSelected(!shape.isSelected());
                    previousSelectedShape = shape;
                }
            } else {
                shape.setSelected(!shape.isSelected());
                previousSelectedShape = shape;
            }

            repaint();
        }
    }

    private static Color getRandomColor() {
        int red   = random.nextInt(256);
        int green = random.nextInt(256);
        int blue  = random.nextInt(256);

        return new Color(red, green, blue);
    }

    private static Shape getInitialRectangle() {
        Rectangle rectangle = new objects.Rectangle(PREVIEW_MARGIN, PREVIEW_MARGIN, PREVIEW_SIZE, PREVIEW_SIZE);
        rectangle.setColor(getRandomColor());

        return rectangle;
    }

    private static Shape getInitialCircle() {
        int radius = PREVIEW_SIZE / 2;
        Circle circle = new objects.Circle(PREVIEW_MARGIN + radius, PREVIEW_MARGIN + radius, radius);
        circle.setColor(getRandomColor());

        return circle;
    }

    private static int findShape(List<Shape> list, int x, int y) {
        for (int i = list.size() - 1; i >= 0; --i) {
            objects.Shape shape = list.get(i);
            if (shape.contains(x, y)) {
                return i;
            }
        }

        return -1;
    }

    private static Stack<Shape> loadShapes() {
        Stack<Shape> shapes = new Stack<>();

        Path shapeFilePath = Paths.get(System.getProperty("user.home"), SHAPE_FILE_NAME);
        if (shapeFilePath.toFile().exists()) {
            try {
                shapes = Serializer.load(shapeFilePath);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return shapes;
    }

    private static void saveShapes(Serializable shapes) {
        Path shapeFilePath = Paths.get(System.getProperty("user.home"), SHAPE_FILE_NAME);
        try {
            Serializer.save(shapes, shapeFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
