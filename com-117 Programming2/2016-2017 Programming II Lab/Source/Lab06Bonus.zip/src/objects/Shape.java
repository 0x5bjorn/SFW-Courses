package objects;

import java.awt.*;
import java.io.Serializable;

public abstract class Shape implements Cloneable, Serializable {

    private static final int DEFAULT_SELECTED_BORDER_THICKNESS = 3;
    public static final Color DEFAULT_SELECTED_BORDER_COLOR = Color.WHITE;

    private int x, y;
    private Color color;

    private boolean selected;

    private int selectedBorderThickness;
    private Color selectedBorderColor;

    public Shape(int x, int y) {
        this.x = x;
        this.y = y;

        color = Color.BLACK;

        selected = false;
        selectedBorderThickness = DEFAULT_SELECTED_BORDER_THICKNESS;
        selectedBorderColor = DEFAULT_SELECTED_BORDER_COLOR;
    }

    @Override
    public final Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException ignored) {
            return null;
        }
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public int getSelectedBorderThickness() {
        return selectedBorderThickness;
    }

    public void setSelectedBorderThickness(int selectedBorderThickness) {
        this.selectedBorderThickness = selectedBorderThickness;
    }

    public Color getSelectedBorderColor() {
        return selectedBorderColor;
    }

    public void setSelectedBorderColor(Color selectedBorderColor) {
        this.selectedBorderColor = selectedBorderColor;
    }

    public abstract boolean isPositionedAtCenter();

    public abstract void updateBounds(int width, int height);

    public abstract boolean contains(int x, int y);

    public abstract void draw(Graphics2D g);

}
